package pa.parcial2.service.implementacion;

import pa.parcial2.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Implementación del servicio de email usando JavaMailSender de Spring.
 * Envía correos simples de texto plano al triatleta registrado.
 * Configuración SMTP en application.properties.
 */
@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {

    /** Componente de Spring para el envío de correos electrónicos. */
    private final JavaMailSender mailSender;

    /**
     * Construye un mensaje simple con asunto y cuerpo personalizados y lo envía.
     */
    @Override
    public void enviarCorreoRegistro(String destino, String nombre) {
        SimpleMailMessage mensaje = new SimpleMailMessage();
        mensaje.setTo(destino);
        mensaje.setSubject("Bienvenido al Triatlon Olimpico - Registro Exitoso");
        mensaje.setText(
                "Hola " + nombre + ",\n\n"
                + "Tu registro en la competencia de Triatlon fue exitoso.\n"
                + "Bienvenido a la comunidad de triatletas!\n\n"
                + "Equipo de Triatlon Olimpico"
        );
        mailSender.send(mensaje);
    }

}
