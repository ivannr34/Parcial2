package pa.parcial2.modelo;

/**
 * Enumeración de especialidades del triatlón según distancia.
 */
public enum Especialidad {
    /** 350m natación + 10km ciclismo + 2.5km carrera. */
    SUPER_SPRINT,
    /** 750m natación + 20km ciclismo + 5km carrera. */
    SPRINT,
    /** 1.5km natación + 40km ciclismo + 10km carrera. Modalidad Olímpica. */
    OLIMPICA,
    /** 1.9-3km natación + 80-90km ciclismo + 20km carrera. */
    MEDIA_DISTANCIA,
    /** 1-4km natación + 100-200km ciclismo + 42km carrera. Incluye el Ironman. */
    LARGA_DISTANCIA,
    /** 10km natación + 415km ciclismo + 85km carrera. Se divide en 3 días. */
    ULTRAMAN
}
