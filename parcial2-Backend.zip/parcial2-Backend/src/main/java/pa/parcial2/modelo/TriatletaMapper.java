package pa.parcial2.modelo;

import pa.parcial2.dto.TriatletaResponseDTO;

/**
 * Clase utilitaria encargada de convertir entre la entidad Triatleta y sus DTOs.
 * Responsabilidad única solo realiza la conversión de tipos.
 * Ni la entidad ni el DTO conocen cómo convertirse entre sí.
 */
public class TriatletaMapper {

    /**
     * Convierte una entidad Triatleta en un TriatletaResponseDTO para enviarlo al FrontEnd.
     *
     * @param triatleta La entidad JPA con todos los datos de BD.
     * @return TriatletaResponseDTO con los datos listos para el cliente.
     */
    public static TriatletaResponseDTO toResponse(Triatleta triatleta) {
        if (triatleta == null) {
            return null;
        }
        return new TriatletaResponseDTO(
                triatleta.getId(),
                triatleta.getNombre(),
                triatleta.getIdentificacion(),
                triatleta.getEdad(),
                triatleta.getGenero(),
                triatleta.getCorreo(),
                triatleta.getCategoria(),
                triatleta.getEspecialidad(),
                triatleta.getModalidad(),
                triatleta.getCross(),
                triatleta.getFoto()
        );
    }

}
