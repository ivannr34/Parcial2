package pa.parcial2.control;

import pa.parcial2.dto.TriatletaRequestDTO;
import pa.parcial2.dto.TriatletaResponseDTO;
import pa.parcial2.modelo.Categoria;
import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import pa.parcial2.service.TriatletaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

/**
 * controlador REST para las operaciones CRUD del Triatleta.
 * expone los endpoints de la API que consume el FrontEnd vía fetch().
 * usa @RequestMapping para todos los mapeos, como requiere el parcial.
 * regresa ResponseDTO en lugar de la entidad JPA directamente.
 *
 */
@RestController
@RequestMapping("/api/triatletas")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TriatletaControl {

    /** Servicio de logica de negocio del triatleta. */
    private final TriatletaService service;

    /**
     * Registra un nuevo triatleta en el sistema
     * POST /api/triatletas
     *
     * @param dto Datos del triatleta enviados en el body (JSON).
     * @return 200 OK con el TriatletaResponseDTO guardado.
     */
    @RequestMapping(method = RequestMethod.POST)
    public ResponseEntity<TriatletaResponseDTO> registrar(
            @Valid @RequestBody TriatletaRequestDTO dto) {
        return ResponseEntity.ok(service.registrar(dto));
    }

    /**
     * Consulta un triatleta por su número de identificación.
     * GET /api/triatletas/identificacion/{identificacion}
     *
     * @param identificacion Número de documento a buscar.
     * @return 200 OK con el triatleta, o 404 si no existe.
     */
    @RequestMapping(value = "/identificacion/{identificacion}", method = RequestMethod.GET)
    public ResponseEntity<TriatletaResponseDTO> buscar(
            @PathVariable String identificacion) {
        return ResponseEntity.ok(service.buscarPorIdentificacion(identificacion));
    }

    /**
     * Lista todos los triatletas registrados.
     * GET /api/triatletas
     *
     * @return Lista completa de triatletas.
     */
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<TriatletaResponseDTO>> listarTodos() {
        return ResponseEntity.ok(service.listarTodos());
    }

    /**
     * Lista triatletas filtrados por género.
     * GET /api/triatletas/genero/{genero}
     *
     * @param genero Género a filtrar (MASCULINO, FEMENINO, OTRO).
     * @return Lista de triatletas con ese género.
     */
    @RequestMapping(value = "/genero/{genero}", method = RequestMethod.GET)
    public ResponseEntity<List<TriatletaResponseDTO>> porGenero(
            @PathVariable Genero genero) {
        return ResponseEntity.ok(service.listarPorGenero(genero));
    }

    /**
     * Lista triatletas filtrados por categoría.
     * GET /api/triatletas/categoria/{categoria}
     *
     * @param categoria Categoría a filtrar.
     * @return Lista de triatletas en esa categoría.
     */
    @RequestMapping(value = "/categoria/{categoria}", method = RequestMethod.GET)
    public ResponseEntity<List<TriatletaResponseDTO>> porCategoria(
            @PathVariable Categoria categoria) {
        return ResponseEntity.ok(service.listarPorCategoria(categoria));
    }

    /**
     * Lista triatletas filtrados por especialidad.
     * GET /api/triatletas/especialidad/{especialidad}
     *
     * @param especialidad Especialidad a filtrar.
     * @return Lista de triatletas con esa especialidad.
     */
    @RequestMapping(value = "/especialidad/{especialidad}", method = RequestMethod.GET)
    public ResponseEntity<List<TriatletaResponseDTO>> porEspecialidad(
            @PathVariable Especialidad especialidad) {
        return ResponseEntity.ok(service.listarPorEspecialidad(especialidad));
    }

    /**
     * Lista triatletas según si participan en modalidad cross.
     * GET /api/triatletas/cross/{cross}
     *
     * @param cross true para cross, false para road.
     * @return Lista de triatletas según modalidad.
     */
    @RequestMapping(value = "/cross/{cross}", method = RequestMethod.GET)
    public ResponseEntity<List<TriatletaResponseDTO>> porCross(
            @PathVariable Boolean cross) {
        return ResponseEntity.ok(service.listarPorCross(cross));
    }

    /**
     * Modifica solo el nombre de un triatleta.
     * PATCH /api/triatletas/{id}/nombre?nombre=NuevoNombre
     *
     * @param id     ID del triatleta a modificar.
     * @param nombre Nuevo nombre.
     * @return Triatleta actualizado.
     */
    @RequestMapping(value = "/{id}/nombre", method = RequestMethod.PATCH)
    public ResponseEntity<TriatletaResponseDTO> actualizarNombre(
            @PathVariable Long id,
            @RequestParam String nombre) {
        return ResponseEntity.ok(service.actualizarNombre(id, nombre));
    }

    /**
     * Modifica solo la identificación de un triatleta.
     * PATCH /api/triatletas/{id}/identificacion?identificacion=NuevoDoc
     *
     * @param id             ID del triatleta a modificar.
     * @param identificacion Nueva identificación.
     * @return Triatleta actualizado.
     */
    @RequestMapping(value = "/{id}/identificacion", method = RequestMethod.PATCH)
    public ResponseEntity<TriatletaResponseDTO> actualizarIdentificacion(
            @PathVariable Long id,
            @RequestParam String identificacion) {
        return ResponseEntity.ok(service.actualizarIdentificacion(id, identificacion));
    }

    /**
     * Modifica solo la categoría de un triatleta.
     * PATCH /api/triatletas/{id}/categoria?categoria=ABSOLUTA
     *
     * @param id        ID del triatleta a modificar.
     * @param categoria Nueva categoría.
     * @return Triatleta actualizado.
     */
    @RequestMapping(value = "/{id}/categoria", method = RequestMethod.PATCH)
    public ResponseEntity<TriatletaResponseDTO> actualizarCategoria(
            @PathVariable Long id,
            @RequestParam Categoria categoria) {
        return ResponseEntity.ok(service.actualizarCategoria(id, categoria));
    }

    /**
     * Elimina un triatleta del sistema.
     * DELETE /api/triatletas/{id}
     *
     * @param id ID del triatleta a eliminar.
     * @return 204 No Content si fue eliminado correctamente.
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

}
