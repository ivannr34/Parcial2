package pa.parcial2.repository;

import pa.parcial2.modelo.Categoria;
import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import pa.parcial2.modelo.Modalidad;
import pa.parcial2.modelo.Triatleta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * repositorio JPA para la entidad Triatleta.
 * extiende JpaRepository para obtener operaciones CRUD básicas de Spring Data.
 * los métodos adicionales son generados automáticamente por el nombre (Query Methods).
 */
@Repository
public interface TriatletaRepository extends JpaRepository<Triatleta, Long> {

    /**
     * Busca un triatleta por su número de identificación.
     *
     * @param identificacion Número de documento del triatleta.
     * @return Optional con el triatleta si existe y vacío si no.
     */
    Optional<Triatleta> findByIdentificacion(String identificacion);

    /**
     * Lista todos los triatletas de un género específico.
     *
     * @param genero Género a filtrar (MASCULINO, FEMENINO, OTRO).
     * @return Lista de triatletas con ese género.
     */
    List<Triatleta> findByGenero(Genero genero);

    /**
     * Lista todos los triatletas de una categoría específica.
     *
     * @param categoria Categoría a filtrar (CADETE, JUNIOR, ABSOLUTA, etc.).
     * @return Lista de triatletas en esa categoría.
     */
    List<Triatleta> findByCategoria(Categoria categoria);

    /**
     * Lista todos los triatletas de una especialidad específica.
     *
     * @param especialidad Especialidad a filtrar (SPRINT, OLIMPICA, etc.).
     * @return Lista de triatletas con esa especialidad.
     */
    List<Triatleta> findByEspecialidad(Especialidad especialidad);

    /**
     * Lista todos los triatletas según si participan o no en modalidad cross.
     *
     * @param cross true si participan en cross, false si no.
     * @return Lista de triatletas con ese valor de cross.
     */
    List<Triatleta> findByCross(Boolean cross);

}
