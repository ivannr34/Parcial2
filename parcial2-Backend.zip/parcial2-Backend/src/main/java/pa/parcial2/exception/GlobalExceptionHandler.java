package pa.parcial2.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import java.util.Map;

/**
 * manejador global de excepciones para todos los controladores REST.
 * intercepta excepciones específicas y retorna respuestas HTTP con código apropiado.
 * y centraliza el manejo de errores en un solo lugar.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Maneja la excepción ResourceNotFoundException y retorna HTTP 404.
     *
     * @param ex La excepción lanzada desde el Service.
     * @return ResponseEntity con código 404 y mensaje de error en JSON.
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<?> manejarNoEncontrado(ResourceNotFoundException ex) {
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(Map.of("error", ex.getMessage()));
    }

}
