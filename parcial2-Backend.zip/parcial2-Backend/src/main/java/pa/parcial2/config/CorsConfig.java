package pa.parcial2.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * configuración global de políticas CORS.
 * permite que el proyecto FrontEnd pueda comunicarse
 * con este BackEnd Spring Boot sin restricciones de origen.
 */
@Configuration
public class CorsConfig {

    /**
     * configura los mapeos CORS para todos los endpoints de la API.
     * permite todos los orígenes, métodos HTTP y cabeceras necesarias.
     *
     * @return WebMvcConfigurer con la configuración CORS aplicada.
     */
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins("*")
                        .allowedMethods("GET", "POST", "PUT", "PATCH", "DELETE")
                        .allowedHeaders("*");
            }
        };
    }

}
