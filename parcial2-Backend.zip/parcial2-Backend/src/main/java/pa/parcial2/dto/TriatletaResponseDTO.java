package pa.parcial2.dto;

import pa.parcial2.modelo.Categoria;
import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import pa.parcial2.modelo.Modalidad;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO (Data Transfer Object) de respuesta para el Triatleta.
 * Se usa para enviar datos al FrontEnd sin exponer la entidad JPA directamente.
 * No incluye campos sensibles ni anotaciones de persistencia.
 *
 * 
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TriatletaResponseDTO {

    /** Identificador único del triatleta en la BD. */
    private Long id;

    /** Nombre completo del triatleta. */
    private String nombre;

    /** Número de identificación del triatleta. */
    private String identificacion;

    /** Edad del triatleta. */
    private Integer edad;

    /** Género del triatleta. */
    private Genero genero;

    /** Correo electrónico del triatleta. */
    private String correo;

    /** Categoría calculada según la edad. */
    private Categoria categoria;

    /** Especialidad de triatlón preferida. */
    private Especialidad especialidad;

    /** Modalidad de competición (ROAD o CROSS). */
    private Modalidad modalidad;

    /** Indica si participa en modalidad cross. */
    private Boolean cross;

    /** Foto en Base64. */
    private String foto;

}
