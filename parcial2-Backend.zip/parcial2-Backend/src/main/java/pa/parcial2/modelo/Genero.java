package pa.parcial2.modelo;

/**
 * Enumeración que representa el género del triatleta.
 */
public enum Genero {
    /** Género masculino. */
    MASCULINO,
    /** Género femenino. */
    FEMENINO,
    /** Otro género. */
    OTRO
}
