package pa.parcial2.dto;

import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import pa.parcial2.modelo.Modalidad;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO (Data Transfer Object) de entrada para el registro y modificación del Triatleta.
 * recibe los datos del FrontEnd via JSON en el cuerpo de la petición HTTP.
 * incluye validaciones con Jakarta Validation para garantizar integridad de datos.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TriatletaRequestDTO {

    /** nombre completo del triatleta. No puede estar vacío. */
    @NotBlank(message = "El nombre es obligatorio")
    private String nombre;

    /** numero de identificación del triatleta. No puede estar vacío. */
    @NotBlank(message = "La identificacion es obligatoria")
    private String identificacion;

    /** edad del triatleta. Mínimo 7 años (Pre-benjamín). */
    @Min(value = 7, message = "La edad minima es 7 anios")
    private Integer edad;

    /** género del triatleta. */
    private Genero genero;

    /** correo electrónico valido. Se usa para enviar confirmación de registro. */
    @Email(message = "El correo debe tener formato valido")
    private String correo;

    /** especialidad de triatlón según distancia preferida. */
    private Especialidad especialidad;

    /** modalidad de participación: ROAD o CROSS. */
    private Modalidad modalidad;

    /** indica si participa en modalidad cross (true/false). */
    private Boolean cross;

    /** foto del triatleta en formato Base64. */
    private String foto;

}
