package pa.parcial2.exception;

/**
 * Excepción personalizada lanzada cuando no se encuentra un recurso en la BD.
 * Usada por el Service cuando un triatleta no existe para el id o identificación buscada.
 * El GlobalExceptionHandler la intercepta y retorna un HTTP 404.
 *
 * @author Ivan Andres Peñaloza Quintero - Jeronimo Cubillos Gomez
 */
public class ResourceNotFoundException extends RuntimeException {

    /**
     * Construye la excepción con un mensaje descriptivo del recurso no encontrado.
     *
     * @param mensaje Descripción del error (ej: "No se encontro triatleta con id: 5").
     */
    public ResourceNotFoundException(String mensaje) {
        super(mensaje);
    }

}
