package pa.parcial2.service.implementacion;

import pa.parcial2.dto.TriatletaRequestDTO;
import pa.parcial2.dto.TriatletaResponseDTO;
import pa.parcial2.exception.ResourceNotFoundException;
import pa.parcial2.modelo.Categoria;
import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import pa.parcial2.modelo.Triatleta;
import pa.parcial2.modelo.TriatletaMapper;
import pa.parcial2.repository.TriatletaRepository;
import pa.parcial2.service.EmailService;
import pa.parcial2.service.TriatletaService;
import pa.parcial2.util.CategoriaUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementación concreta del servicio de Triatleta.
 * Contiene la lógica de negocio: calcular categoría, guardar, buscar, modificar y eliminar.
 * Usa el Mapper para convertir entidades a DTOs antes de retornar al controlador.
 */
@Service
@RequiredArgsConstructor
public class TriatletaServiceImpl implements TriatletaService {

    /** Repositorio JPA para acceso a la base de datos. */
    private final TriatletaRepository repository;

    /** Servicio de email para notificación de registro. */
    private final EmailService emailService;

    /**
     * Calcula la categoría automáticamente desde la edad y envía correo de registro.
     */
    @Override
    public TriatletaResponseDTO registrar(TriatletaRequestDTO dto) {
        Triatleta triatleta = Triatleta.builder()
                .correo(dto.getCorreo())
                .categoria(CategoriaUtil.calcularCategoria(dto.getEdad()))
                .especialidad(dto.getEspecialidad())
                .modalidad(dto.getModalidad())
                .cross(dto.getCross())
                .foto(dto.getFoto())
                .build();
        triatleta.setNombre(dto.getNombre());
        triatleta.setEdad(dto.getEdad());
        triatleta.setGenero(dto.getGenero());
        triatleta.setIdentificacion(dto.getIdentificacion());

        Triatleta guardado = repository.save(triatleta);

        emailService.enviarCorreoRegistro(guardado.getCorreo(), guardado.getNombre());

        return TriatletaMapper.toResponse(guardado);
    }

    /**
     * Lanza ResourceNotFoundException si no existe el triatleta con esa identificación.
     */
    @Override
    public TriatletaResponseDTO buscarPorIdentificacion(String identificacion) {
        Triatleta t = repository.findByIdentificacion(identificacion)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No se encontro triatleta con identificacion: " + identificacion));
        return TriatletaMapper.toResponse(t);
    }

    @Override
    public List<TriatletaResponseDTO> listarTodos() {
        return repository.findAll()
                .stream()
                .map(TriatletaMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TriatletaResponseDTO> listarPorGenero(Genero genero) {
        return repository.findByGenero(genero)
                .stream()
                .map(TriatletaMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TriatletaResponseDTO> listarPorCategoria(Categoria categoria) {
        return repository.findByCategoria(categoria)
                .stream()
                .map(TriatletaMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TriatletaResponseDTO> listarPorEspecialidad(Especialidad especialidad) {
        return repository.findByEspecialidad(especialidad)
                .stream()
                .map(TriatletaMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TriatletaResponseDTO> listarPorCross(Boolean cross) {
        return repository.findByCross(cross)
                .stream()
                .map(TriatletaMapper::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Lanza ResourceNotFoundException si no existe el triatleta con ese id.
     */
    @Override
    public TriatletaResponseDTO actualizarNombre(Long id, String nombre) {
        Triatleta t = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No se encontro triatleta con id: " + id));
        t.setNombre(nombre);
        return TriatletaMapper.toResponse(repository.save(t));
    }

    /**
     * Lanza ResourceNotFoundException si no existe el triatleta con ese id.
     */
    @Override
    public TriatletaResponseDTO actualizarIdentificacion(Long id, String identificacion) {
        Triatleta t = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No se encontro triatleta con id: " + id));
        t.setIdentificacion(identificacion);
        return TriatletaMapper.toResponse(repository.save(t));
    }

    /**
     * Lanza ResourceNotFoundException si no existe el triatleta con ese id.
     */
    @Override
    public TriatletaResponseDTO actualizarCategoria(Long id, Categoria categoria) {
        Triatleta t = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "No se encontro triatleta con id: " + id));
        t.setCategoria(categoria);
        return TriatletaMapper.toResponse(repository.save(t));
    }

    /**
     * Lanza ResourceNotFoundException si no existe el triatleta con ese id.
     */
    @Override
    public void eliminar(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException(
                    "No se encontro triatleta con id: " + id);
        }
        repository.deleteById(id);
    }

}
