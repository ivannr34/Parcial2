package pa.parcial2.service;

/**
 * Interfaz del servicio de correo electrónico.
 * Define el contrato para el envío de notificaciones por email.
 *
 * @author Ivan Andres Peñaloza Quintero - Jeronimo Cubillos Gomez
 */
public interface EmailService {

    /**
     * Envía un correo de bienvenida al triatleta recién registrado.
     *
     * @param destino Dirección de correo del triatleta.
     * @param nombre  Nombre del triatleta para personalizar el mensaje.
     */
    void enviarCorreoRegistro(String destino, String nombre);

}
