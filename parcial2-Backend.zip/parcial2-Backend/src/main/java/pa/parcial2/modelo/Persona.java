package pa.parcial2.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.MappedSuperclass;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Clase abstracta que representa a una persona en el sistema.
 * Sirve como superclase de la jerarquía de herencia (Persona - Atleta, Persona - Juez).
 * Usa @MappedSuperclass para que JPA mapee los campos en la tabla de la subclase.
 */
@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public abstract class Persona {

    /** Nombre completo de la persona. */
    @Column(name = "nombre", nullable = false, length = 100)
    protected String nombre;

    /** Número de identificación único de la persona. */
    @Column(name = "identificacion", nullable = false, unique = true, length = 50)
    protected String identificacion;

    /** Edad de la persona. Determina la categoría en el triatlón. */
    @Column(name = "edad", nullable = false)
    protected Integer edad;

    /** Género de la persona. */
    @Enumerated(EnumType.STRING)
    @Column(name = "genero", nullable = false, length = 20)
    protected Genero genero;

}
