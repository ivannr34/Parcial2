package pa.parcial2.modelo;

/**
 * Enumeración de categorías del triatlón según edad del participante.
 * Incluye categorías de edad escolar y competitivas.
 */
public enum Categoria {
    /** Edad: 7 años. */
    PRE_BENJAMIN,
    /** Edad: 8-9 años. */
    BENJAMIN,
    /** Edad: 10-11 años. */
    ALEVIN,
    /** Edad: 12-13 años. */
    INFANTIL,
    /** Edad: 14-15 años. */
    CADETE,
    /** Edad: 16-17 años. */
    JUVENIL,
    /** Edad: 18-19 años. */
    JUNIOR,
    /** Edad: 20-23 años. */
    SUB23,
    /** Edad: 24-39 años. Categoría competitiva principal. */
    ABSOLUTA,
    /** Edad: 40-49 años. */
    VETERANO1,
    /** Edad: 50-59 años. */
    VETERANO2,
    /** Edad: 60 o más años. */
    VETERANO3
}
