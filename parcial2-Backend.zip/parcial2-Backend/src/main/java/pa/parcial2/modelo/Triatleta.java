package pa.parcial2.modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Entidad JPA que representa a un Triatleta en el sistema.
 * Hereda los atributos básicos de Persona y agrega los propios del deporte.
 * La foto se almacena como Base64 (String largo).
 */
@Entity
@Table(name = "triatletas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Triatleta extends Persona {

    /** Identificador único generado automáticamente por la BD. */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /** Correo electrónico del triatleta. Se usa para enviar el correo de registro. */
    @Email
    @Column(name = "correo", nullable = false, length = 150)
    private String correo;

    /** Categoría del triatleta según su edad (Cadete, Juvenil, Junior, etc.). */
    @Enumerated(EnumType.STRING)
    @Column(name = "categoria", nullable = false, length = 20)
    private Categoria categoria;

    /** Especialidad de triatlón según distancia (Sprint, Olímpica, Ironman, etc.). */
    @Enumerated(EnumType.STRING)
    @Column(name = "especialidad", nullable = false, length = 20)
    private Especialidad especialidad;

    /** Modalidad de participación (ROAD o CROSS). */
    @Enumerated(EnumType.STRING)
    @Column(name = "modalidad", nullable = false, length = 10)
    private Modalidad modalidad;

    /** Indica si el triatleta participa en modalidad cross (true) o no (false). */
    @Column(name = "cross", nullable = false)
    private Boolean cross;

    /**
     * Foto del triatleta en formato Base64.
     * Se usa @Lob para permitir cadenas de texto largas en la BD.
     */
    @Lob
    @Column(name = "foto", columnDefinition = "LONGTEXT")
    private String foto;

}
