package pa.parcial2.modelo;

/**
 * Enumeración que representa la modalidad del circuito de ciclismo en el triatlón.
 *
 * @author Ivan Andres Peñaloza Quintero - Jeronimo Cubillos Gomez
 */
public enum Modalidad {
    /** Ciclismo en carretera. */
    ROAD,
    /** Ciclismo en modalidad cross (BTT - caminos y montaña). */
    CROSS
}
