package pa.parcial2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la aplicación Spring Boot para el Segundo Parcial - Triatlon.
 * El paquete base pa.parcial2 garantiza que Spring escanee todos los componentes
 * (controladores, servicios, repositorios, configuraciones) automáticamente.
 */
@SpringBootApplication
public class Parcial2Application {

    /**
     * Punto de entrada de la aplicación.
     *
     * @param args Argumentos de línea de comandos (no requeridos).
     */
    public static void main(String[] args) {
        SpringApplication.run(Parcial2Application.class, args);
    }

}
