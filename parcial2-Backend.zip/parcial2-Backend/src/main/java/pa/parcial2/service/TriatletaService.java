package pa.parcial2.service;

import pa.parcial2.dto.TriatletaRequestDTO;
import pa.parcial2.dto.TriatletaResponseDTO;
import pa.parcial2.modelo.Categoria;
import pa.parcial2.modelo.Especialidad;
import pa.parcial2.modelo.Genero;
import java.util.List;

/**
 * Interfaz de servicio para las operaciones sobre el Triatleta.
 * Define el contrato de negocio. La implementación concreta está en TriatletaServiceImpl.
 * Principio ISP (SOLID): interfaz específica solo para Triatleta.
 *
 * @author Ivan Andres Peñaloza Quintero - Jeronimo Cubillos Gomez
 */
public interface TriatletaService {

    /**
     * Registra un nuevo triatleta, calcula su categoría y envía correo de bienvenida.
     *
     * @param dto Datos del triatleta recibidos desde el FrontEnd.
     * @return TriatletaResponseDTO con los datos guardados, incluyendo el id generado.
     */
    TriatletaResponseDTO registrar(TriatletaRequestDTO dto);

    /**
     * Busca un triatleta por su número de identificación.
     *
     * @param identificacion Número de documento a buscar.
     * @return TriatletaResponseDTO con los datos del triatleta encontrado.
     */
    TriatletaResponseDTO buscarPorIdentificacion(String identificacion);

    /**
     * Lista todos los triatletas registrados en el sistema.
     *
     * @return Lista de TriatletaResponseDTO con todos los triatletas.
     */
    List<TriatletaResponseDTO> listarTodos();

    /**
     * Lista triatletas filtrados por género.
     *
     * @param genero Género a filtrar.
     * @return Lista de triatletas con ese género.
     */
    List<TriatletaResponseDTO> listarPorGenero(Genero genero);

    /**
     * Lista triatletas filtrados por categoría.
     *
     * @param categoria Categoría a filtrar.
     * @return Lista de triatletas en esa categoría.
     */
    List<TriatletaResponseDTO> listarPorCategoria(Categoria categoria);

    /**
     * Lista triatletas filtrados por especialidad de triatlón.
     *
     * @param especialidad Especialidad a filtrar.
     * @return Lista de triatletas con esa especialidad.
     */
    List<TriatletaResponseDTO> listarPorEspecialidad(Especialidad especialidad);

    /**
     * Lista triatletas filtrados por modalidad cross.
     *
     * @param cross true para modalidad cross, false para sin cross.
     * @return Lista de triatletas según modalidad.
     */
    List<TriatletaResponseDTO> listarPorCross(Boolean cross);

    /**
     * Actualiza solo el nombre de un triatleta.
     *
     * @param id     ID del triatleta a modificar.
     * @param nombre Nuevo nombre.
     * @return TriatletaResponseDTO actualizado.
     */
    TriatletaResponseDTO actualizarNombre(Long id, String nombre);

    /**
     * Actualiza solo la identificación de un triatleta.
     *
     * @param id             ID del triatleta a modificar.
     * @param identificacion Nueva identificación.
     * @return TriatletaResponseDTO actualizado.
     */
    TriatletaResponseDTO actualizarIdentificacion(Long id, String identificacion);

    /**
     * Actualiza solo la categoría de un triatleta.
     *
     * @param id        ID del triatleta a modificar.
     * @param categoria Nueva categoría.
     * @return TriatletaResponseDTO actualizado.
     */
    TriatletaResponseDTO actualizarCategoria(Long id, Categoria categoria);

    /**
     * Elimina un triatleta del sistema por su ID.
     *
     * @param id ID del triatleta a eliminar.
     */
    void eliminar(Long id);

}
